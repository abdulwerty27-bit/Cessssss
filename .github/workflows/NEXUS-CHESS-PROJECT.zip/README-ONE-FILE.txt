NEXUS CHESS — ONE FILE GITHUB UPLOAD

1) Upload ONLY NEXUS-CHESS-PROJECT.zip to the ROOT of your GitHub repository.
2) The workflow file .github/workflows/build-android.yml must exist in the repository and must contain the archive-unpacking workflow supplied in this project ZIP (see .github/workflows/build-android.yml).
3) After replacing the workflow once, upload/replace NEXUS-CHESS-PROJECT.zip for future updates. GitHub Actions will unzip it automatically and build the APK.
4) Open Actions > Build Android APK > Run workflow. Download nexus-chess-debug-apk from Artifacts after a green check.

Important: GitHub does not automatically unpack ZIP files uploaded through the website. The workflow must be configured to unzip the archive. This project includes the correct workflow file.
